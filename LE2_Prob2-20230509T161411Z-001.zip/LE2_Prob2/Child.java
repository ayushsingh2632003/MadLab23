class Child extends Mother{
    
    
    
  public void call(){
        System.out.println("Child called");
}
}