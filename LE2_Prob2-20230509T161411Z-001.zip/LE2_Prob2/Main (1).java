
public class Main
{
    public static void main(String[] args){

Child ch = new Child();


ch.call();


}
}
