public class Mother{
    public void call(){
        System.out.println("Mother called");
    }

        
    }
