class Child extends Mother{
    
    
    
  public static void call(){
        System.out.println("Child called");
}
}