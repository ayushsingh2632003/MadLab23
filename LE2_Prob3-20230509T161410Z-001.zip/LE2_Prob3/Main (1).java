
public class Main
{
    public static void main(String[] args){

//Child ch = new Child();


//ch.call();



// child called 
Mother m1 = new Child();
m1.call();

//without static function will call the method of the formed object class ;//no runtimepolymorphism
////with static function will call the method of the formed reference variable type; //polymorphism take place;
}
}
