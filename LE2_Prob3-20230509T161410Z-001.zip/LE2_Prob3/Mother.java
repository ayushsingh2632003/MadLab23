public class Mother{
    public static void call(){
        System.out.println("Mother called");
        
        
    }


        
    }
