
public class Main
{
    public static void main(String[] args){
        // error One o = new One(); 
        Two t = new Two();
        


}
}
