public class One{
    int x;
    
    One(int x){
        this.x=x;
        System.out.println(x);
        
    }
    
}