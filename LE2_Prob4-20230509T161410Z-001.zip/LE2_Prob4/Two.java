public class Two extends One{
    
    Two(){
    super(20);
    }
    
    
    
    

   
    
    
}