public class arjun extends pndv{
   public void kind(){
        System.out.println("arjun was more kind than bheem");
    }
}