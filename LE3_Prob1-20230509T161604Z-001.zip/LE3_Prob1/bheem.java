public class  bheem extends pndv{
   public void kind(){
        System.out.println("bheem was less kind than arjun");
    }
}