public class  korav extends btv{
    public void fight(){
        System.out.println("koravas were fighter but less than pandavas");
        
    }
    public void kind(){
        System.out.println("koravas were not kind ");
    }
    
       
    
    public void obd(){
        System.out.println("koravas were not obidient");
    }
    
}