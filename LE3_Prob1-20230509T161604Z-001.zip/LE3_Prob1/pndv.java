public abstract class pndv extends btv{
  
    
    public  void obd(){
        System.out.println("pandavas were equally obidient");
    }
    public abstract void  kind();
    
    
    
    
    
    
    
    
    
}