public class vikarn extends korav{
    public void kind(){
        System.out.println("vikarn were kind ");
    }
    public void obd(){
        System.out.println("vikarn was obidient");
    }
}


