abstract class AbsTest implements Testable{
 
}