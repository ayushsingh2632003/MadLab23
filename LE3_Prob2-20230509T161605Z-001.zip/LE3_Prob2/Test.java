class Test implements Testable{
    public void speak(){
        System.out.println("Hello");
    }
}