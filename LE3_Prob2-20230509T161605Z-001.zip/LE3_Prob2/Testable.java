interface Testable{
     void speak();
}