 class Duck{
    public   void swim(){
        System.out.println("tair gyi  bhaiya");
    }
}