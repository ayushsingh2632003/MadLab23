class LD extends Duck implements quackable,flyable{
    public void quack(){
        System.out.println("kaww kaww");
        
    }
    public void fly(){
        System.out.println("udja kale kawa mere");
    }
    
}