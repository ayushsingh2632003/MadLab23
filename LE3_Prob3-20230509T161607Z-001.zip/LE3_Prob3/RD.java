class RD extends Duck implements quackable,flyable{
   public  void quack(){
        System.out.println("i squeak");
    }
    public void fly(){
        System.out.println("nhi ud pauga ");
    }
} 