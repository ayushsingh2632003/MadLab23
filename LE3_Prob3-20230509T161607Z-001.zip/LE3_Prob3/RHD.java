class RHD extends Duck implements quackable,flyable{
    public void quack(){
        System.out.println("i quack ");
    }
    public void fly(){
        System.out.println("udi udi jaaye ");
    }
}