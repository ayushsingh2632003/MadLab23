class WD extends Duck{
 
}