interface flyable {
    void fly();
}