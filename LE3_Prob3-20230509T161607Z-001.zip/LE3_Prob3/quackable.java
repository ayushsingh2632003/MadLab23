interface quackable {
    void quack();
}